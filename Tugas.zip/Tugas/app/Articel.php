<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Articel extends Model
{
    protected $table ='articel';
    
    protected $fillable = [
       'judul', 'penulis', 'isi', 'gambar'
    ];

    public function coment(){
    	return $this->belongsTo(Articel::class,'id_articel');
    }
}
