<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Coment extends Model
{
    protected $table ='coment';
    
    protected $fillable = [
       'id_articel','nama', 'email', 'website', 'massage'
    ];

    public function articel(){
    	return $this->belongsTo(Coment::class,'id');
    }
}
