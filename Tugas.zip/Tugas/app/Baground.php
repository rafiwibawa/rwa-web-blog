<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Baground extends Model
{
    protected $table ='baground';
    
    protected $fillable = [
       'website','gambar', 'email', 'telepon', 'alamat'
    ];
}
