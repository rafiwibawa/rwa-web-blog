<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Articel;
use App\Coment;
use App\Contact;

class UserController extends Controller
{
    public function read($id)
    {
        // $article = \App\Articel::all();
        $article= DB::table('articel')->where('id',$id)->get();
        $coment= DB::table('coment')->where('id_articel',$id)->get();
        return view('home.readmore', ['article' => $article,'coment' => $coment]);
    }
}
