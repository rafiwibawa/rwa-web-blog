<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Articel;
use App\Coment;
use App\Contact;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
    //  * @return void
    //  */
    public function __construct()
    {
        date_default_timezone_set("Asia/Jakarta");
        $this->middleware('guest')->except('logout');
    }

    /**
     * Show the application dashboard.
     *
    //  * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $article = DB::table('articel')->paginate(5);
        return view('home.indek', ['article' => $article]);
    }

    public function articel()
    {
        $article = \App\Articel::all();
        return view('home.articel', ['article' => $article]);
    }
    
    public function contact()
    {
        return view('home.contact');
    }
    
    public function contact_save(Request $req)
    {
        Contact::create([
            'nama' => $req->name,
            'email' => $req->email,
            'subject' => $req->subject,
            'massage' => $req->massage,
        ]);
        return view('home.contact');
    }

    public function coment(Request $req)
    {
        // echo $req['text'];
        Coment::create([
            'id_articel' => $req->id,
            'nama' => $req->name,
            'email' => $req->email,
            'website' => $req->website,
            'massage'=> $req->text,
        ]);
        // $article= DB::table('articel')->where('id',$req->id)->get();
        // return view('home.readmore', ['article' => $article]);

        $article= DB::table('articel')->where('id',$req->id)->get();
        $coment= DB::table('coment')->where('id_articel',$req->id)->get();

        return view('home.readmore', ['article' => $article,'coment' => $coment]);
        // return view('readmore');
    }
}
