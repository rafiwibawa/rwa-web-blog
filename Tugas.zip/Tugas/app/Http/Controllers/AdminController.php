<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Articel;
use App\User;

class AdminController extends Controller
{
    
    public function __construct()
    {
        date_default_timezone_set("Asia/Jakarta");
        $this->middleware('auth');
    }

    public function index(){
        return view('admin.indek');
    }

    public function baground(){
        $baground = \App\Baground::all();
        return view('admin.baground', ['baground' => $baground]);
    }

    public function baground_edit(Request $req){
        if ($req->file != NULL) {
            $file = $req->file;
            $tujuan_upload = 'img';
            
            $file->move($tujuan_upload,$file->getClientOriginalName());
    
            $test=DB::table('baground')->where('id',$req['id'])->update([
                'website' => $req->name,
                'email' => $req->email,
                'telepon' => $req->telepon,
                'alamat' => $req->alamat,
                'Quotes' => $req->quotes,
                'gambar'=> $file->getClientOriginalName(),
            ]);
        }else{
            $test=DB::table('baground')->where('id',$req['id'])->update([
                'website' => $req->name,
                'email' => $req->email,
                'telepon' => $req->telepon,
                'alamat' => $req->alamat,
                'Quotes' => $req->quotes,
            ]);
        }
        return redirect('baground');
    }

    public function articel(){
        $article = \App\Articel::all();
        return view('admin.articel', ['article' => $article]);
    }

    public function articel_save(Request $req){
        $file = $req->file;
        $tujuan_upload = 'img';
        
        $file->move($tujuan_upload,$file->getClientOriginalName());

        Articel::create([
            'judul' => $req->judul,
            'penulis' => $req->penulis,
            'isi' => $req->text,
            'gambar'=> $file->getClientOriginalName(),
        ]);
        return redirect('articel');
    }

    public function articel_edit(Request $req){
        if ($req->file != NULL) {
            $file = $req->file;
            $tujuan_upload = 'img';
            
            $file->move($tujuan_upload,$file->getClientOriginalName());
    
            $test=DB::table('articel')->where('id',$req['id'])->update([
                'judul' => $req->judul,
                'penulis' => $req->penulis,
                'isi' => $req->text,
                'gambar'=> $file->getClientOriginalName(),
            ]);
        }else{
            $test=DB::table('articel')->where('id',$req['id'])->update([
                'judul' => $req->judul,
                'penulis' => $req->penulis,
                'isi' => $req->text,
            ]);
        }
        // var_dump($req->file);
        return redirect('articel');
    }

    public function coment(){
        return view('admin.coment');
    }

    public function contact(){
        $contact = \App\Contact::all();
        return view('admin.contact',['contact' => $contact]);
    }

    public function user(){
        $user = \App\User::all();
        return view('admin.user', ['user' => $user]);
    }

    public function user_hapus($id){
        DB::table('users')->where('id',$id)->delete();
        // return redirect('/kegiatan')-> with ('status','Data Kegiatan Berhasil Dihapus');
        $user = \App\User::all();
        return view('admin.user', ['user' => $user]);
    }

    public function user_edit(Request $req){
        DB::table('users')->where('id',$req['id'])->update([
        'name' => $req->name,
        'email' => $req->email,
    ]);
        $user = \App\User::all();
        return view('admin.user', ['user' => $user]);
    }
}
