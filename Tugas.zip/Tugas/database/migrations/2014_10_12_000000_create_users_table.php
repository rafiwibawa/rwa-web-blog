<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->Increments('id');
            $table->string('name');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->rememberToken();
            $table->timestamps();
        });

        Schema::create('articel', function (Blueprint $table) {
            $table->Increments('id');
            $table->string('judul');
            $table->string('penulis');
            $table->text('isi');
            $table->string('gambar');
            $table->rememberToken();
            $table->timestamps();
        });

        Schema::create('coment', function (Blueprint $table) {
            $table->Increments('id');
            $table->unsignedInteger('id_articel');
            $table->string('nama');
            $table->string('email');
            $table->text('website');
            $table->text('massage');
            $table->rememberToken();
            $table->timestamps();
        });

        Schema::table('coment', function (Blueprint $table) {
            $table->foreign('id_articel')->references('id')->on('articel')->onDelete('cascade')->onUpdate('cascade');
        });

        Schema::create('contact', function (Blueprint $table) {
            $table->Increments('id');
            $table->string('nama');
            $table->string('email');
            $table->string('subject');
            $table->string('massage');
            $table->rememberToken();
            $table->timestamps();
        });

        Schema::create('baground', function (Blueprint $table) {
            $table->Increments('id');
            $table->string('website');
            $table->string('gambar');
            $table->text('Quotes');
            $table->string('email');
            $table->string('telepon');
            $table->string('alamat');
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
        Schema::dropIfExists('articel');
        Schema::dropIfExists('coment');
        Schema::dropIfExists('contact');
    }
}
