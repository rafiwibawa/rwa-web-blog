<?php $__env->startSection('content'); ?>
<style type="text/css">
    .pagination li {
        float: left;
        list-style-type: none;
        margin: 5px;
    }

</style>
<?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="case">
    <div class="row">
        <div class="col-md-6 col-lg-6 col-xl-8 d-flex">
            <a href="blog-single.html" class="img w-100 mb-3 mb-md-0"
                style="background-image: url(img/<?php echo e($ar->gambar); ?>);"></a>
        </div>
        <div class="col-md-6 col-lg-6 col-xl-4 d-flex">
            <div class="text w-100 pl-md-3">
                <span class="subheading">Penulis : <?php echo e($ar->penulis); ?></span>
                <h2><a href="blog-single.html"><?php echo e($ar->judul); ?></a></h2>
                <?php
                $tampil = substr($ar->isi,0,150);
                ?>
                <td><?php echo e($tampil."..."); ?></td>
                <ul class="media-social list-unstyled">
                    <li class="ftco-animate"><a href="https://twitter.com/login?lang=id"><span
                                class="icon-twitter"></span></a></li>
                    <li class="ftco-animate"><a href="https://www.facebook.com/"><span class="icon-facebook"></span></a>
                    </li>
                    <li class="ftco-animate"><a href="https://www.instagram.com/?hl=id"><span
                                class="icon-instagram"></span></a></li>
                </ul>
                <div class="meta">
                    <p class="mb-0"><a href="#"><?php echo e($ar->created_at); ?></a> | <a href="/read/<?php echo e($ar->id); ?>">ReadMore</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<br />
Halaman : <?php echo e($article->currentPage()); ?> <br />
Jumlah Data : <?php echo e($article->total()); ?> <br />
Data Per Halaman : <?php echo e($article->perPage()); ?> <br />
<?php echo e($article->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LAPORAN_TA_PIUN\laravel\Tugas\resources\views/home/indek.blade.php ENDPATH**/ ?>