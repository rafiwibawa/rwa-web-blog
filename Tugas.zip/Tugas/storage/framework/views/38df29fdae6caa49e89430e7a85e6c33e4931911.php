<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
     <h1 class="h3 mb-0 text-gray-800">Contact</h1>
     
   </div>
   <div class="container-fluid">
  <!-- Content Row -->
  <div class="row">
    <div class="col-xl-12 col-md-6 mb-12">
      <div class="card border-left shadow h-100 py-12">
        <div class="card-body">
          <!-- DataTales Example -->
            <h6 class="m-0 font-weight-bold text-primary">DataTables Aticel</h6>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>Name Website</th>
                    <th>Gambar Baground</th>
                    <th>Quotes</th>
                    <th>email</th>
                    <th>telephon</th>
                    <th>Alamat</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <?php $__currentLoopData = $baground; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ba): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                  <tr>
                  <td><?php echo e($ba->website); ?></td>
                    <td><?php echo e($ba->gambar); ?></td>
                    <td><?php echo e($ba->Quotes); ?></td>
                    <td><?php echo e($ba->email); ?></td>
                    <td><?php echo e($ba->telepon); ?></td>
                    <td><?php echo e($ba->alamat); ?></td> 
                    <td>
                      <a href="" data-toggle="modal" data-target="#edit" class="btn btn-warning btn-circle">
                        <i class="fas fa-edit"></i>
                      </a>
                    </td>
                  </tr>
                </tbody>

                  <!-- Modal edit-->
                  <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
                    aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalCenterTitle">Edit Articel</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="card-body">
                                    <form method="POST" action="/baground" enctype="multipart/form-data" >
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" id="id" name="id" value="<?php echo e($ba->id); ?>">
                                        <div class="form-group row">
                                            <label for="name" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Name')); ?></label>
                    
                                            <div class="col-md-12">
                                                <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name"
                                                 value="<?php echo e($ba->website); ?>" required autocomplete="name" autofocus>
                    
                                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                          <label for="email" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Email')); ?></label>
                  
                                          <div class="col-md-12">
                                              <input id="email" type="text-area" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email"
                                                value="<?php echo e($ba->email); ?>" placeholder="" required autocomplete="email">
                  
                                              <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                                  <span class="invalid-feedback" role="alert">
                                                      <strong><?php echo e($email); ?></strong>
                                                  </span>
                                              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                          </div>
                                      </div>
                    
                                        <div class="form-group row">
                                          <label for="telepon" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Telephon')); ?></label>
                  
                                          <div class="col-md-12">
                                              <input id="telepon" type="text-area" class="form-control <?php if ($errors->has('telepon')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telepon'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="telepon"
                                                value="<?php echo e($ba->telepon); ?>" placeholder="" required autocomplete="telepon">
                  
                                              <?php if ($errors->has('massage')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('massage'); ?>
                                                  <span class="invalid-feedback" role="alert">
                                                      <strong><?php echo e($telepon); ?></strong>
                                                  </span>
                                              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                          </div>
                                      </div>

                                      <div class="form-group row">
                                        <label for="penulis" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Alamat')); ?></label>
                
                                        <div class="col-md-12">
                                            <input id="alamat" type="text-area" class="form-control <?php if ($errors->has('alamat')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('alamat'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="alamat"
                                              value="<?php echo e($ba->alamat); ?>" placeholder="" required autocomplete="alamat">
                
                                            <?php if ($errors->has('penulis')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('penulis'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($alamat); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                      <label for="text">Isi</label>
                                      <textarea name="quotes"  id="quotes" cols="82" rows="10" placeholder="text"><?php echo e($ba->Quotes); ?></textarea>
                                    </div>
                    
                                        <div class="form-group row">
                                            <b class="col-md-12 col-form-label text-md-left">Gambar</b><br/>
                                            <div class="col-md-8">
                                              <input type="file" name="file" id="file">
                                            </div>
                                            <div class="col-md-4">
                                              <img class="img-profile rounded-circle" height="100px" width="100px" src="/img/<?php echo e($ba->gambar); ?>" alt="">
                                             </div>
                                        </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-danger"><?php echo e(__('Save')); ?> </button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    </div>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>
            </div>
          </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.hedadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LAPORAN_TA_PIUN\laravel\Tugas\resources\views/admin/baground.blade.php ENDPATH**/ ?>