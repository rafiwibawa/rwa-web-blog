<?php $__env->startSection('content'); ?>
<?php 
    $kat = DB::table('baground')->get();
    $judul = DB::table('articel')->max('judul');
    $gambar = DB::table('articel')->max('gambar');
    $created_at = DB::table('articel')->max('created_at');
    $id = DB::table('articel')->max('id');
?>
<div class="hero-wrap js-fullheight" style="background-image: url('/img/<?php echo e($kat[0]->gambar); ?>');" data-stellar-background-ratio="0.5">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-center">
      <div class="col-md-9 ftco-animate pb-5 text-center">
        <h1 class="mb-3 bread">Article us</h1>
        <p class="breadcrumbs"><span class="mr-2"><a href="/home">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Article <i class="ion-ios-arrow-forward"></i></span></p>
      </div>
    </div>
    </div>
  </div>
</div>


<section class="ftco-section bg-dark">
  <div class="container">
      <div class="row">
          <div class="col-md-12">


 <section class="ftco-section ">
    <div class="container">
      <div class="row d-flex">
         <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 d-flex ftco-animate">
            <div class="blog-entry justify-content-end">
            <a href="blog-single.html" class="block-20" style="background-image: url('img/<?php echo e($ar->gambar); ?>');">
            </a>
            <div class="text p-4 float-right d-block">
                <div class="topper d-flex align-items-center">
                    <div class="one py-2 pl-3 pr-1 align-self-stretch">
                    <span class="day"><?php echo e(date('d', strtotime($ar->created_at))); ?></span>
                    </div>
                    <div class="two pl-0 pr-3 py-2 align-self-stretch">
                        <span class="yr"><?php echo e(date('y', strtotime($ar->created_at))); ?></span>
                        <span class="mos"><?php
                            if(date('m', strtotime($ar->created_at))=='01'){echo "January";}
                            else if(date('m', strtotime($ar->created_at))=='02'){echo "Ferbuary";}
                            else if(date('m', strtotime($ar->created_at))=='03'){echo "Maret";}
                            else if(date('m', strtotime($ar->created_at))=='04'){echo "April";}
                            else if(date('m', strtotime($ar->created_at))=='05'){echo "Mei";}
                            else if(date('m', strtotime($ar->created_at))=='06'){echo "Juni";}
                            else if(date('m', strtotime($ar->created_at))=='07'){echo "Juli";}
                            else if(date('m', strtotime($ar->created_at))=='08'){echo "Agustus";}
                            else if(date('m', strtotime($ar->created_at))=='09'){echo "September";}
                            else if(date('m', strtotime($ar->created_at))=='10'){echo "Oktober";}
                            else if(date('m', strtotime($ar->created_at))=='11'){echo "November";}
                            else if(date('m', strtotime($ar->created_at))=='12'){echo "Desember";}
                        ?></span>
                    </div>
                </div>
                <h3 class="heading mb-3"><a href="#"><?php echo e($ar->penulis); ?></a></h3>
                <?php
                $tampil = substr($ar->isi,0,50);
                ?>
              <p><?php echo e($tampil."..."); ?></p>
              <p><a href="/read/<?php echo e($ar->id); ?>" class="btn-custom"><span class="ion-ios-arrow-round-forward mr-3"></span>Read more</a></p>
            </div>
          </div>
        </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      <div class="row mt-5">
        <div class="col text-center">
        </div>
      </div>
    </div>
  </section>
</div>
</div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project Rafi\Bekasi\Tugas\resources\views/home/articel.blade.php ENDPATH**/ ?>