<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
     <h1 class="h3 mb-0 text-gray-800">Articel</h1>
     <a href="#" data-toggle="modal" data-target="#tambah" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Tambah Articel</a>
   </div>

 <!-- Content Row -->
 <div class="row">
   <div class="col-xl-12 col-md-6 mb-12">
     <div class="card border-left shadow h-100 py-12">
       <div class="card-body">
         <!-- DataTales Example -->
           <h6 class="m-0 font-weight-bold text-primary">DataTables Aticel</h6>
         </div>
         <div class="card-body">
           <div class="table-responsive">
             <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
               <thead>
                 <tr>
                   <th>Nama</th>
                   <th>Email</th>
                   <th>Tanggal aktif</th>
                   <th>Aksi</th>
                 </tr>
               </thead>
               <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tbody>
                 <tr>
                   <td><?php echo e($ar->name); ?></td>
                   <td><?php echo e($ar->email); ?></td>
                   <td><?php echo e($ar->created_at); ?></td>
                   <td>
                     <a href="" data-toggle="modal" data-target="#edit<?php echo e($ar->id); ?>" class="btn btn-warning btn-circle">
                       <i class="fas fa-edit"></i>
                     </a>
                    <a title="Hapus Data" href="user/hapus<?php echo e($ar->id); ?>"
                       onClick="return confirm('Yakin Ingin menghapus data?')"
                       class="btn btn-danger btn-circle"><span
                       class="fas fa-trash"></span></a>
                     </a>
                   </td>
                 </tr>
               </tbody>
               <!-- Modal edit-->
             <div class="modal fade" id="edit<?php echo e($ar->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
               aria-hidden="true">
               <div class="modal-dialog modal-dialog-centered" role="document">
                   <div class="modal-content">
                       <div class="modal-header">
                           <h5 class="modal-title" id="exampleModalCenterTitle">Edit Articel</h5>
                           <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                               <span aria-hidden="true">&times;</span>
                           </button>
                       </div>
                       <div class="modal-body">
                           <div class="card-body">
                               <form method="POST" action="/user/edit" enctype="multipart/form-data" >
                                   <?php echo csrf_field(); ?>
                                   <input type="hidden" id="id" name="id" value="<?php echo e($ar->id); ?>">
                                   <div class="form-group row">
                                       <label for="name" class="col-md-4 col-form-label text-md-left"><?php echo e(__('name')); ?></label>
               
                                       <div class="col-md-12">
                                           <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name"
                                            value="<?php echo e($ar->name); ?>" required autocomplete="name" autofocus>
               
                                           <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                               <span class="invalid-feedback" role="alert">
                                                   <strong><?php echo e($message); ?></strong>
                                               </span>
                                           <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                       </div>
                                   </div>
               
                                   <div class="form-group row">
                                       <label for="email" class="col-md-4 col-form-label text-md-left"><?php echo e(__('email')); ?></label>
               
                                       <div class="col-md-12">
                                           <input id="penulis" type="text-area" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email"
                                             value="<?php echo e($ar->email); ?>" placeholder="" required autocomplete="email">
               
                                           <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                               <span class="invalid-feedback" role="alert">
                                                   <strong><?php echo e($message); ?></strong>
                                               </span>
                                           <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                       </div>
                                   </div>
                           </div>
                       </div>
                       <div class="modal-footer">
                           <button type="submit" class="btn btn-danger"><?php echo e(__('Save')); ?> </button>
                           <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                           </form>
                       </div>
                   </div>
               </div>
               </div>
               
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </table>
           </div>
         </div>
       </div>
   </div>
</div>

<!-- Modal Tambah-->
<div class="modal fade" id="tambah" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
aria-hidden="true">
<div class="modal-dialog modal-dialog-centered" role="document">
 <div class="modal-content">
     <div class="modal-header">
         <h5 class="modal-title" id="exampleModalCenterTitle">Tambah User</h5>
         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
             <span aria-hidden="true">&times;</span>
         </button>
     </div>
     <div class="modal-body">
         <div class="card-body">
            <form method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>

                <div class="form-group row">
                    <label for="name" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Name')); ?></label>

                    <div class="col-md-8">
                        <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                        <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="email" class="col-md-4 col-form-label text-md-left"><?php echo e(__('E-Mail Address')); ?></label>

                    <div class="col-md-8">
                        <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="password" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Password')); ?></label>

                    <div class="col-md-8">
                        <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="password-confirm" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Confirm Password')); ?></label>

                    <div class="col-md-8">
                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                    </div>
                </div>
         </div>
     </div>
     <div class="modal-footer">
         <button type="submit" class="btn btn-danger"><?php echo e(__('Save')); ?> </button>
         <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
         </form>
     </div>
 </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.hedadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LAPORAN_TA_PIUN\laravel\Tugas\resources\views/admin/user.blade.php ENDPATH**/ ?>