<?php $__env->startSection('content'); ?>

 <section class="ftco-section bg-light">
    <div class="container">
      <div class="row d-flex">
         <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 d-flex ftco-animate">
            <div class="blog-entry justify-content-end">
            <a href="blog-single.html" class="block-20" style="background-image: url('img/<?php echo e($ar->gambar); ?>');">
            </a>
            <div class="text p-4 float-right d-block">
                <div class="topper d-flex align-items-center">
                    <div class="one py-2 pl-3 pr-1 align-self-stretch">
                    <span class="day"><?php echo e(date('d', strtotime($ar->created_at))); ?></span>
                    </div>
                    <div class="two pl-0 pr-3 py-2 align-self-stretch">
                        <span class="yr"><?php echo e(date('y', strtotime($ar->created_at))); ?></span>
                        <span class="mos"><?php
                            if(date('m', strtotime($ar->created_at))=='01'){echo "January";}
                            else if(date('m', strtotime($ar->created_at))=='02'){echo "Ferbuary";}
                            else if(date('m', strtotime($ar->created_at))=='03'){echo "Maret";}
                            else if(date('m', strtotime($ar->created_at))=='04'){echo "April";}
                            else if(date('m', strtotime($ar->created_at))=='05'){echo "Mei";}
                            else if(date('m', strtotime($ar->created_at))=='06'){echo "Juni";}
                            else if(date('m', strtotime($ar->created_at))=='07'){echo "Juli";}
                            else if(date('m', strtotime($ar->created_at))=='08'){echo "Agustus";}
                            else if(date('m', strtotime($ar->created_at))=='09'){echo "September";}
                            else if(date('m', strtotime($ar->created_at))=='10'){echo "Oktober";}
                            else if(date('m', strtotime($ar->created_at))=='11'){echo "November";}
                            else if(date('m', strtotime($ar->created_at))=='12'){echo "Desember";}
                        ?></span>
                    </div>
                </div>
                <h3 class="heading mb-3"><a href="#"><?php echo e($ar->penulis); ?></a></h3>
                <?php
                $tampil = substr($ar->isi,0,50);
                ?>
              <p><?php echo e($tampil."..."); ?></p>
              <p><a href="/read/<?php echo e($ar->id); ?>" class="btn-custom"><span class="ion-ios-arrow-round-forward mr-3"></span>Read more</a></p>
            </div>
          </div>
        </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      <div class="row mt-5">
        <div class="col text-center">
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LAPORAN_TA_PIUN\laravel\Tugas\resources\views/home/articel.blade.php ENDPATH**/ ?>