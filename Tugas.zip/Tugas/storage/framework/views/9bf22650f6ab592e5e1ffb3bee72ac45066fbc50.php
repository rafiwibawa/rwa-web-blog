<?php $__env->startSection('content'); ?>

<section class="ftco-section ftco-degree-bg">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 ftco-animate">
            <p class="mb-5">
          <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <img src="/img/<?php echo e($ar->gambar); ?>" alt="" class="img-fluid">
          </p>
          <h2 class="mb-5"><?php echo e($ar->judul); ?></h2>
          <p>
            <?php echo e($ar->isi); ?>

          </p>
            <b> Penulis : <?php echo e($ar->penulis); ?> </b>
          </p>
         <!-- <p><?php echo e($ar->isi); ?></p> -->
          <!-- <p>Odit voluptatibus, eveniet vel nihil cum ullam dolores laborum, quo velit commodi rerum eum quidem pariatur! Quia fuga iste tenetur, ipsa vel nisi in dolorum consequatur, veritatis porro explicabo soluta commodi libero voluptatem similique id quidem? Blanditiis voluptates aperiam non magni. Reprehenderit nobis odit inventore, quia laboriosam harum excepturi ea.</p>
          <p>Adipisci vero culpa, eius nobis soluta. Dolore, maxime ullam ipsam quidem, dolor distinctio similique asperiores voluptas enim, exercitationem ratione aut adipisci modi quod quibusdam iusto, voluptates beatae iure nemo itaque laborum. Consequuntur et pariatur totam fuga eligendi vero dolorum provident. Voluptatibus, veritatis. Beatae numquam nam ab voluptatibus culpa, tenetur recusandae!</p>
          <p>Voluptas dolores dignissimos dolorum temporibus, autem aliquam ducimus at officia adipisci quasi nemo a perspiciatis provident magni laboriosam repudiandae iure iusto commodi debitis est blanditiis alias laborum sint dolore. Dolores, iure, reprehenderit. Error provident, pariatur cupiditate soluta doloremque aut ratione. Harum voluptates mollitia illo minus praesentium, rerum ipsa debitis, inventore?</p> --}}
          <div class="tag-widget post-tag-container mb-5 mt-5">
            <div class="tagcloud">
              <a href="#" class="tag-cloud-link">Life</a>
              <a href="#" class="tag-cloud-link">Sport</a>
              <a href="#" class="tag-cloud-link">Tech</a>
              <a href="#" class="tag-cloud-link">Travel</a>
            </div>
          </div> -->
          
          <!-- <div class="about-author d-flex p-4 bg-light">
            <div class="bio mr-5">
              <img src="/img/<?php echo e($ar->gambar); ?>" alt="Image placeholder" class="img-fluid mb-4">
            </div>
            <div class="desc">
              <h3>George Washington</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus itaque, autem necessitatibus voluptate quod mollitia delectus aut, sunt placeat nam vero culpa sapiente consectetur similique, inventore eos fugit cupiditate numquam!</p>
            </div>
          </div> -->
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php $__currentLoopData = $coment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $co): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="pt-5 mt-5">
            <h3 class="mb-5">Comments</h3>
            <ul class="comment-list">

              <li class="comment">
                <div class="vcard bio">
                  <i class="fas fa-user"></i>
                  <!-- <img src="images/person_1.jpg" alt="Image placeholder"> -->
                </div>
                <div class="comment-body">
                  <h3><?php echo e($co->nama); ?></h3>
                  <div class="meta mb-3"></div>
                  <p><?php echo e($co->massage); ?></p>
                  <!-- <p><a href="#" class="reply">Reply</a></p> -->
                </div>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <!-- END comment-list -->
            
            <div class="comment-form-wrap pt-5">
              <h3 class="mb-5">Leave a comment</h3>
              <form method="POST" action="/coment" class="p-5 bg-light" enctype="multipart/form-data">
                <?php echo csrf_field(); ?> 
                <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <input type="hidden" name="id" id="id" value="<?php echo e($ar->id); ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group">
                  <label for="name">Name *</label>
                  <input type="text" class="form-control" id="name" name="name">
                </div>
                <div class="form-group">
                  <label for="email">Email *</label>
                  <input type="email" class="form-control" id="email" name="email">
                </div>
                <div class="form-group">
                  <label for="website">Website</label>
                  <input type="url" class="form-control" id="website" name="website">
                </div>

                <div class="form-group">
                  <label for="text">Message</label>
                  
                  <textarea cols="30" rows="10" class="form-control" id="text" name="text" ></textarea>
                </div>
                <div class="form-group">
                  <input type="submit" value="Post Comment" class="btn py-3 px-4 btn-primary">
                </div>

              </form>
            </div>
          </div>
          </div>
        <!-- .col-md-8 -->
        <div class="col-lg-4 sidebar pl-lg-5 ftco-animate">
          <!--  -->

          <!-- <div class="sidebar-box ftco-animate"> -->
            <h3>Recent Blog</h3>
            <?php
            $articel = DB::table('articel')->paginate(10);
            ?>
            <?php $__currentLoopData = $articel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="block-21 mb-4 d-flex">
              <a class="blog-img mr-4" style="background-image: url(/img/<?php echo e($articel->gambar); ?>);"></a>
              <div class="text">
                <h3 class="heading"><a href="#"><?php echo e($articel->judul); ?></a></h3>
                <div class="meta">
                  <div><a href="#"><span class="icon-calendar"></span><?php echo e($articel->created_at); ?></a></div>
                  <div><a href="#"><span class="icon-person"></span> Admin</a></div>
                  <!--  -->
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <!--  -->

          <!-- <div class="sidebar-box ftco-animate">
            <h3>Paragraph</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus itaque, autem necessitatibus voluptate quod mollitia delectus aut, sunt placeat nam vero culpa sapiente consectetur similique, inventore eos fugit cupiditate numquam!</p>
          </div> -->
        <!-- </div> -->
      </div>
      </div>
    </div>
  <!-- </div> -->
  </section> <!-- .section -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project Rafi\Bekasi\Tugas\resources\views/home/readmore.blade.php ENDPATH**/ ?>