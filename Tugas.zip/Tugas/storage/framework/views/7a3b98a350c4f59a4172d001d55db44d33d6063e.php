<?php $__env->startSection('content'); ?>
<?php 
    $kat = DB::table('baground')->get();
    $judul = DB::table('articel')->max('judul');
    $gambar = DB::table('articel')->max('gambar');
    $created_at = DB::table('articel')->max('created_at');
    $id = DB::table('articel')->max('id');
?>

<div class="hero-wrap js-fullheight" style="background-image: url('/img/<?php echo e($kat[0]->gambar); ?>');" data-stellar-background-ratio="0.5">
    
    <div class="container">
      <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-start" data-scrollax-parent="true">
        <div class="col-md-12 ftco-animate">
            <h2 class="subheading">Hello! Welcome to</h2>
            <h1 class="mb-4 mb-md-0"><?php echo e($kat[0]->website); ?></h1>
            <div class="row">
                <div class="col-md-7">
                    <div class="text">
                        <p><?php echo e($kat[0]->Quotes); ?></p>
                        <div class="mouse">
                                      <a href="#" class="mouse-icon">
                                          <div class="mouse-wheel"><span class="ion-ios-arrow-round-down"></span></div>
                                      </a>
                                  </div>
                              </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  </div>


<section class="ftco-section ftco-bg-dark ftco-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">

<style type="text/css">
    .pagination li {
        float: left;
        list-style-type: none;
        margin: 5px;
    }

</style>
<?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="case">
    <div class="row">
        <div class="col-md-6 col-lg-6 col-xl-8 d-flex">
            <a href="blog-single.html" class="img w-100 mb-3 mb-md-0"
                style="background-image: url(img/<?php echo e($ar->gambar); ?>);"></a>
        </div>
        <div class="col-md-6 col-lg-6 col-xl-4 d-flex">
            <div class="text w-100 pl-md-3">
                <span class="subheading text-white">Penulis : <?php echo e($ar->penulis); ?></span>
                <h2><a href="blog-single.html text-dark"><?php echo e($ar->judul); ?></a></h2>
                <?php
                $tampil = substr($ar->isi,0,150);
                ?>
                <td><?php echo e($tampil."..."); ?></td>
                <ul class="media-social list-unstyled">
                    <li class="ftco-animate"><a href="https://twitter.com/login?lang=id"><span
                                class="icon-twitter"></span></a></li>
                    <li class="ftco-animate"><a href="https://www.facebook.com/"><span class="icon-facebook"></span></a>
                    </li>
                    <li class="ftco-animate"><a href="https://www.instagram.com/?hl=id"><span
                                class="icon-instagram"></span></a></li>
                </ul>
                <div class="meta">
                    <p class="mb-0 e"><a href="#"  class="mb-0 text-white"><?php echo e($ar->created_at); ?></a> | <a href="/read/<?php echo e($ar->id); ?>"  class="mb-0 text-white">ReadMore</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<br />
Halaman : <?php echo e($article->currentPage()); ?> <br />
Jumlah Data : <?php echo e($article->total()); ?> <br />
Data Per Halaman : <?php echo e($article->perPage()); ?> <br />
<?php echo e($article->links()); ?>

</div>
</div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project Rafi\Bekasi\Tugas\resources\views/home/indek.blade.php ENDPATH**/ ?>