<?php $__env->startSection('content'); ?>
<div class="container-fluid">
       <!-- Page Heading -->
       <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Articel</h1>
        <a href="#" data-toggle="modal" data-target="#tambah" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Tambah Articel</a>
      </div>
  
    <!-- Content Row -->
    <div class="row">
      <div class="col-xl-12 col-md-6 mb-12">
        <div class="card border-left shadow h-100 py-12">
          <div class="card-body">
            <!-- DataTales Example -->
              <h6 class="m-0 font-weight-bold text-primary">DataTables Aticel</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Judul</th>
                      <th>Penulis</th>
                      <th>Isi</th>
                      <th>Tanggal Upload</th>
                      <th>Gambar</th>
                      <th>Aksi</th>
                    </tr>
                  </thead>
                  <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tbody>
                    <tr>
                      <td><?php echo e($ar->judul); ?></td>
                      <td><?php echo e($ar->penulis); ?></td>
                      <?php
                      $tampil = substr($ar->isi,0,50);
                      ?>
                      <td><?php echo e($tampil."..."); ?></td>
                      <td><?php echo e($ar->created_at); ?></td>
                      <td><?php echo e($ar->gambar); ?></td>
                      <td>
                        <a href="" data-toggle="modal" data-target="#edit<?php echo e($ar->id); ?>" class="btn btn-warning btn-circle">
                          <i class="fas fa-edit"></i>
                        </a>
                        <a title="Hapus Data" href="#"
                          onClick="return confirm('Yakin Ingin menghapus data?')"
                          class="btn btn-danger btn-circle"><span
                          class="fas fa-trash"></span></a>
                        </a>
                        <?php 
                            // $user = DB::table('coments')->where('id_articel',{{$ar->id}})->count();
                            // if($user==0){
                            //     $jumlah=0;
                            // }else{
                            //     $jumlah=$user;
                            // }
                        ?>
                        
                      </td>
                    </tr>
                  </tbody>
                  <!-- Modal edit-->
                <div class="modal fade" id="edit<?php echo e($ar->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
                  aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalCenterTitle">Edit Articel</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                              </button>
                          </div>
                          <div class="modal-body">
                              <div class="card-body">
                                  <form method="POST" action="/articel/edit" enctype="multipart/form-data" >
                                      <?php echo csrf_field(); ?>
                                      <input type="hidden" id="id" name="id" value="<?php echo e($ar->id); ?>">
                                      <div class="form-group row">
                                          <label for="judul" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Judul')); ?></label>
                  
                                          <div class="col-md-12">
                                              <input id="judul" type="text" class="form-control <?php if ($errors->has('judul')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('judul'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="judul"
                                               value="<?php echo e($ar->judul); ?>" required autocomplete="name" autofocus>
                  
                                              <?php if ($errors->has('judul')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('judul'); ?>
                                                  <span class="invalid-feedback" role="alert">
                                                      <strong><?php echo e($message); ?></strong>
                                                  </span>
                                              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                          </div>
                                      </div>
                  
                                      <div class="form-group row">
                                          <label for="penulis" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Penulis')); ?></label>
                  
                                          <div class="col-md-12">
                                              <input id="penulis" type="text-area" class="form-control <?php if ($errors->has('penulis')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('penulis'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="penulis"
                                                value="<?php echo e($ar->penulis); ?>" placeholder="" required autocomplete="penulis">
                  
                                              <?php if ($errors->has('penulis')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('penulis'); ?>
                                                  <span class="invalid-feedback" role="alert">
                                                      <strong><?php echo e($message); ?></strong>
                                                  </span>
                                              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                          </div>
                                      </div>
                  
                                      <div class="form-group row">
                                          <label for="text">Isi</label>
                                          <textarea name="text"  id="text" cols="82" rows="10" placeholder="text"><?php echo e($ar->isi); ?></textarea>
                                      </div>
                  
                                      <div class="form-group row">
                                          <b class="col-md-4 col-form-label text-md-left">File Gambar</b><br/>
                                          <div class="col-md-12">
                                              <input type="file" name="file" id="file">
                                          </div>
                                      </div>
                              </div>
                          </div>
                          <div class="modal-footer">
                              <button type="submit" class="btn btn-danger"><?php echo e(__('Save')); ?> </button>
                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                              </form>
                          </div>
                      </div>
                  </div>
                  </div>
                  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
              </div>
            </div>
          </div>
      </div>
  </div>

  <!-- Modal Tambah-->
<div class="modal fade" id="tambah" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
aria-hidden="true">
<div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalCenterTitle">Tambah Articel</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <div class="card-body">
                <form method="POST" action="/articel/save" enctype="multipart/form-data" >
                    <?php echo csrf_field(); ?>

                    <div class="form-group row">
                        <label for="judul" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Judul')); ?></label>

                        <div class="col-md-12">
                            <input id="judul" type="text" class="form-control <?php if ($errors->has('judul')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('judul'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="judul" value="<?php echo e(old('judul')); ?>" required autocomplete="name" autofocus>

                            <?php if ($errors->has('judul')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('judul'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="penulis" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Penulis')); ?></label>

                        <div class="col-md-12">
                            <input id="penulis" type="text-area" class="form-control <?php if ($errors->has('penulis')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('penulis'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="penulis"
                             value="<?php echo e(old('penulis')); ?>" placeholder="" required autocomplete="penulis">

                            <?php if ($errors->has('penulis')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('penulis'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="text">Isi</label>
                        <textarea name="text" id="text" cols="82" rows="10" placeholder="text"></textarea>
                    </div>

                    <div class="form-group row">
                        <b class="col-md-4 col-form-label text-md-left">File Gambar</b><br/>
                        <div class="col-md-12">
                            <input type="file" name="file" id="file">
                        </div>
                    </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-danger"><?php echo e(__('Save')); ?> </button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </form>
        </div>
    </div>
</div>
</div>

 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.hedadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project Rafi\Bekasi\Tugas\resources\views/admin/articel.blade.php ENDPATH**/ ?>