<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

// Auth::routes();

// Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/Logout', function () {
    Auth::logout();
    return redirect('/');
});
// Route::get('/home', 'HomeController@index')->name('home');

// Route::get('/', function () {
//     return view('home.indek');
// });
Route::get('/', 'HomeController@index');
Route::get('/Home', 'HomeController@index');
Route::get('/Articel', 'HomeController@articel');
Route::get('/Contact', 'HomeController@contact');
Route::post('/Contact', 'HomeController@contact_save');
Route::get('/read/{id}', 'UserController@read');
Route::post('/coment', 'HomeController@coment');




Route::get('/home', 'AdminController@index');

Route::get('/articel', 'AdminController@articel');
Route::post('/articel/save', 'AdminController@articel_save');
Route::post('/articel/edit', 'AdminController@articel_edit');

Route::get('/coment', 'AdminController@coment');

Route::get('/contact', 'AdminController@contact');

Route::get('/user', 'AdminController@user');
Route::get('/user/hapus{id}', 'AdminController@user_hapus');
Route::post('/user/edit', 'AdminController@user_edit');

Route::get('/baground', 'AdminController@baground');
Route::post('/baground', 'AdminController@baground_edit');


