@extends('layouts.header')

@section('content')
<?php 
    $kat = DB::table('baground')->get();
    $judul = DB::table('articel')->max('judul');
    $gambar = DB::table('articel')->max('gambar');
    $created_at = DB::table('articel')->max('created_at');
    $id = DB::table('articel')->max('id');
?>
<div class="hero-wrap js-fullheight" style="background-image: url('/img/{{$kat[0]->gambar}}');" data-stellar-background-ratio="0.5">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-center">
      <div class="col-md-9 ftco-animate pb-5 text-center">
        <h1 class="mb-3 bread">Article us</h1>
        <p class="breadcrumbs"><span class="mr-2"><a href="/home">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Article <i class="ion-ios-arrow-forward"></i></span></p>
      </div>
    </div>
    </div>
  </div>
</div>

{{-- Content --}}
<section class="ftco-section bg-dark">
  <div class="container">
      <div class="row">
          <div class="col-md-12">


 <section class="ftco-section ">
    <div class="container">
      <div class="row d-flex">
         @foreach($article as $ar)
        <div class="col-md-4 d-flex ftco-animate">
            <div class="blog-entry justify-content-end">
            <a href="blog-single.html" class="block-20" style="background-image: url('img/{{$ar->gambar}}');">
            </a>
            <div class="text p-4 float-right d-block">
                <div class="topper d-flex align-items-center">
                    <div class="one py-2 pl-3 pr-1 align-self-stretch">
                    <span class="day">{{date('d', strtotime($ar->created_at))}}</span>
                    </div>
                    <div class="two pl-0 pr-3 py-2 align-self-stretch">
                        <span class="yr">{{date('y', strtotime($ar->created_at))}}</span>
                        <span class="mos">@php
                            if(date('m', strtotime($ar->created_at))=='01'){echo "January";}
                            else if(date('m', strtotime($ar->created_at))=='02'){echo "Ferbuary";}
                            else if(date('m', strtotime($ar->created_at))=='03'){echo "Maret";}
                            else if(date('m', strtotime($ar->created_at))=='04'){echo "April";}
                            else if(date('m', strtotime($ar->created_at))=='05'){echo "Mei";}
                            else if(date('m', strtotime($ar->created_at))=='06'){echo "Juni";}
                            else if(date('m', strtotime($ar->created_at))=='07'){echo "Juli";}
                            else if(date('m', strtotime($ar->created_at))=='08'){echo "Agustus";}
                            else if(date('m', strtotime($ar->created_at))=='09'){echo "September";}
                            else if(date('m', strtotime($ar->created_at))=='10'){echo "Oktober";}
                            else if(date('m', strtotime($ar->created_at))=='11'){echo "November";}
                            else if(date('m', strtotime($ar->created_at))=='12'){echo "Desember";}
                        @endphp</span>
                    </div>
                </div>
                <h3 class="heading mb-3"><a href="#">{{$ar->penulis}}</a></h3>
                @php
                $tampil = substr($ar->isi,0,50);
                @endphp
              <p>{{$tampil."..."}}</p>
              <p><a href="/read/{{$ar->id}}" class="btn-custom"><span class="ion-ios-arrow-round-forward mr-3"></span>Read more</a></p>
            </div>
          </div>
        </div>
       @endforeach 
      <div class="row mt-5">
        <div class="col text-center">
        </div>
      </div>
    </div>
  </section>
</div>
</div>
</div>
</section>
@endsection
