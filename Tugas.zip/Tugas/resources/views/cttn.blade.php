@extends('layouts.hedadmin')

@section('content')
<div class="container-fluid">
    <!-- Content Row -->
    <div class="row">
      <div class="col-xl-12 col-md-6 mb-12">
        <div class="card border-left shadow h-100 py-12">
          <div class="card-body">
            <H1>BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB</H1>
          </div>
        </div>
      </div>
  </div>
@endsection
