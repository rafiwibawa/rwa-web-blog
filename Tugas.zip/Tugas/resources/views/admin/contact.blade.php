@extends('layouts.hedadmin')

@section('content')
<div class="container-fluid">
       <!-- Page Heading -->
       <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Contact</h1>
        {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
      </div>
      <div class="container-fluid">
     <!-- Content Row -->
     <div class="row">
       <div class="col-xl-12 col-md-6 mb-12">
         <div class="card border-left shadow h-100 py-12">
           <div class="card-body">
             <!-- DataTales Example -->
               <h6 class="m-0 font-weight-bold text-primary">DataTables Aticel</h6>
             </div>
             <div class="card-body">
               <div class="table-responsive">
                 <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                   <thead>
                     <tr>
                       <th>Name</th>
                       <th>Email</th>
                       <th>Subject</th>
                       <th>Massage</th>
                       <th>Tanggal</th>
                       <th>Aksi</th>
                     </tr>
                   </thead>
                   @foreach($contact as $co)
                   <tbody>
                     <tr>
                     <td>{{$co->nama}}</td>
                       <td>{{$co->email}}</td>
                       <td>{{$co->subject}}</td>
                       <td>{{$co->massage}}</td>
                       <td>{{$co->created_at}}</td> 
                       <td>
                         <a title="Hapus Data" href="#"
                           onClick="return confirm('Yakin Ingin menghapus data?')"
                           class="btn btn-danger btn-circle"><span
                           class="fas fa-trash"></span></a>
                         </a>
                       </td>
                     </tr>
                   </tbody>
                   @endforeach
                 </table>
               </div>
             </div>
           </div>
       </div>
   </div>
  </div>
@endsection
