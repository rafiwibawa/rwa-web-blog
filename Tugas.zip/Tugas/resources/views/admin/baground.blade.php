@extends('layouts.hedadmin')

@section('content')
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
     <h1 class="h3 mb-0 text-gray-800">Contact</h1>
     {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
   </div>
   <div class="container-fluid">
  <!-- Content Row -->
  <div class="row">
    <div class="col-xl-12 col-md-6 mb-12">
      <div class="card border-left shadow h-100 py-12">
        <div class="card-body">
          <!-- DataTales Example -->
            <h6 class="m-0 font-weight-bold text-primary">DataTables Aticel</h6>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>Name Website</th>
                    <th>Gambar Baground</th>
                    <th>Quotes</th>
                    <th>email</th>
                    <th>telephon</th>
                    <th>Alamat</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                @foreach($baground as $ba)
                <tbody>
                  <tr>
                  <td>{{$ba->website}}</td>
                    <td>{{$ba->gambar}}</td>
                    <td>{{$ba->Quotes}}</td>
                    <td>{{$ba->email}}</td>
                    <td>{{$ba->telepon}}</td>
                    <td>{{$ba->alamat}}</td> 
                    <td>
                      <a href="" data-toggle="modal" data-target="#edit" class="btn btn-warning btn-circle">
                        <i class="fas fa-edit"></i>
                      </a>
                    </td>
                  </tr>
                </tbody>

                  <!-- Modal edit-->
                  <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
                    aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalCenterTitle">Edit Articel</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="card-body">
                                    <form method="POST" action="/baground" enctype="multipart/form-data" >
                                        @csrf
                                        <input type="hidden" id="id" name="id" value="{{$ba->id}}">
                                        <div class="form-group row">
                                            <label for="name" class="col-md-4 col-form-label text-md-left">{{ __('Name') }}</label>
                    
                                            <div class="col-md-12">
                                                <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name"
                                                 value="{{$ba->website}}" required autocomplete="name" autofocus>
                    
                                                @error('name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                          <label for="email" class="col-md-4 col-form-label text-md-left">{{ __('Email') }}</label>
                  
                                          <div class="col-md-12">
                                              <input id="email" type="text-area" class="form-control @error('email') is-invalid @enderror" name="email"
                                                value="{{$ba->email}}" placeholder="" required autocomplete="email">
                  
                                              @error('email')
                                                  <span class="invalid-feedback" role="alert">
                                                      <strong>{{ $email }}</strong>
                                                  </span>
                                              @enderror
                                          </div>
                                      </div>
                    
                                        <div class="form-group row">
                                          <label for="telepon" class="col-md-4 col-form-label text-md-left">{{ __('Telephon') }}</label>
                  
                                          <div class="col-md-12">
                                              <input id="telepon" type="text-area" class="form-control @error('telepon') is-invalid @enderror" name="telepon"
                                                value="{{$ba->telepon}}" placeholder="" required autocomplete="telepon">
                  
                                              @error('massage')
                                                  <span class="invalid-feedback" role="alert">
                                                      <strong>{{ $telepon }}</strong>
                                                  </span>
                                              @enderror
                                          </div>
                                      </div>

                                      <div class="form-group row">
                                        <label for="penulis" class="col-md-4 col-form-label text-md-left">{{ __('Alamat') }}</label>
                
                                        <div class="col-md-12">
                                            <input id="alamat" type="text-area" class="form-control @error('alamat') is-invalid @enderror" name="alamat"
                                              value="{{$ba->alamat}}" placeholder="" required autocomplete="alamat">
                
                                            @error('penulis')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $alamat }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                      <label for="text">Isi</label>
                                      <textarea name="quotes"  id="quotes" cols="82" rows="10" placeholder="text">{{$ba->Quotes}}</textarea>
                                    </div>
                    
                                        <div class="form-group row">
                                            <b class="col-md-12 col-form-label text-md-left">Gambar</b><br/>
                                            <div class="col-md-8">
                                              <input type="file" name="file" id="file">
                                            </div>
                                            <div class="col-md-4">
                                              <img class="img-profile rounded-circle" height="100px" width="100px" src="/img/{{$ba->gambar}}" alt="">
                                             </div>
                                        </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-danger">{{ __('Save') }} </button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    </div>
                    {{-- akhir modal edit --}}
                @endforeach
              </table>
            </div>
          </div>
        </div>
    </div>
</div>
</div>
@endsection
