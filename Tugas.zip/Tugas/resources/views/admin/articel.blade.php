@extends('layouts.hedadmin')

@section('content')
<div class="container-fluid">
       <!-- Page Heading -->
       <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Articel</h1>
        <a href="#" data-toggle="modal" data-target="#tambah" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Tambah Articel</a>
      </div>
  
    <!-- Content Row -->
    <div class="row">
      <div class="col-xl-12 col-md-6 mb-12">
        <div class="card border-left shadow h-100 py-12">
          <div class="card-body">
            <!-- DataTales Example -->
              <h6 class="m-0 font-weight-bold text-primary">DataTables Aticel</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Judul</th>
                      <th>Penulis</th>
                      <th>Isi</th>
                      <th>Tanggal Upload</th>
                      <th>Gambar</th>
                      <th>Aksi</th>
                    </tr>
                  </thead>
                  @foreach($article as $ar)
                  <tbody>
                    <tr>
                      <td>{{$ar->judul}}</td>
                      <td>{{$ar->penulis}}</td>
                      @php
                      $tampil = substr($ar->isi,0,50);
                      @endphp
                      <td>{{$tampil."..."}}</td>
                      <td>{{$ar->created_at}}</td>
                      <td>{{$ar->gambar}}</td>
                      <td>
                        <a href="" data-toggle="modal" data-target="#edit{{$ar->id}}" class="btn btn-warning btn-circle">
                          <i class="fas fa-edit"></i>
                        </a>
                        <a title="Hapus Data" href="#"
                          onClick="return confirm('Yakin Ingin menghapus data?')"
                          class="btn btn-danger btn-circle"><span
                          class="fas fa-trash"></span></a>
                        </a>
                        <?php 
                            // $user = DB::table('coments')->where('id_articel',{{$ar->id}})->count();
                            // if($user==0){
                            //     $jumlah=0;
                            // }else{
                            //     $jumlah=$user;
                            // }
                        ?>
                        {{-- <a href="#" class="btn btn-info btn-circle">
                            <i class="fas fa-comments"></i>{{1}}
                        </a> --}}
                      </td>
                    </tr>
                  </tbody>
                  <!-- Modal edit-->
                <div class="modal fade" id="edit{{$ar->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
                  aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalCenterTitle">Edit Articel</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                              </button>
                          </div>
                          <div class="modal-body">
                              <div class="card-body">
                                  <form method="POST" action="/articel/edit" enctype="multipart/form-data" >
                                      @csrf
                                      <input type="hidden" id="id" name="id" value="{{$ar->id}}">
                                      <div class="form-group row">
                                          <label for="judul" class="col-md-4 col-form-label text-md-left">{{ __('Judul') }}</label>
                  
                                          <div class="col-md-12">
                                              <input id="judul" type="text" class="form-control @error('judul') is-invalid @enderror" name="judul"
                                               value="{{$ar->judul}}" required autocomplete="name" autofocus>
                  
                                              @error('judul')
                                                  <span class="invalid-feedback" role="alert">
                                                      <strong>{{ $message }}</strong>
                                                  </span>
                                              @enderror
                                          </div>
                                      </div>
                  
                                      <div class="form-group row">
                                          <label for="penulis" class="col-md-4 col-form-label text-md-left">{{ __('Penulis') }}</label>
                  
                                          <div class="col-md-12">
                                              <input id="penulis" type="text-area" class="form-control @error('penulis') is-invalid @enderror" name="penulis"
                                                value="{{$ar->penulis}}" placeholder="" required autocomplete="penulis">
                  
                                              @error('penulis')
                                                  <span class="invalid-feedback" role="alert">
                                                      <strong>{{ $message }}</strong>
                                                  </span>
                                              @enderror
                                          </div>
                                      </div>
                  
                                      <div class="form-group row">
                                          <label for="text">Isi</label>
                                          <textarea name="text"  id="text" cols="82" rows="10" placeholder="text">{{$ar->isi}}</textarea>
                                      </div>
                  
                                      <div class="form-group row">
                                          <b class="col-md-4 col-form-label text-md-left">File Gambar</b><br/>
                                          <div class="col-md-12">
                                              <input type="file" name="file" id="file">
                                          </div>
                                      </div>
                              </div>
                          </div>
                          <div class="modal-footer">
                              <button type="submit" class="btn btn-danger">{{ __('Save') }} </button>
                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                              </form>
                          </div>
                      </div>
                  </div>
                  </div>
                  {{-- akhir modal edit --}}
                  @endforeach
                </table>
              </div>
            </div>
          </div>
      </div>
  </div>

  <!-- Modal Tambah-->
<div class="modal fade" id="tambah" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
aria-hidden="true">
<div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalCenterTitle">Tambah Articel</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <div class="card-body">
                <form method="POST" action="/articel/save" enctype="multipart/form-data" >
                    @csrf

                    <div class="form-group row">
                        <label for="judul" class="col-md-4 col-form-label text-md-left">{{ __('Judul') }}</label>

                        <div class="col-md-12">
                            <input id="judul" type="text" class="form-control @error('judul') is-invalid @enderror" name="judul" value="{{ old('judul') }}" required autocomplete="name" autofocus>

                            @error('judul')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="penulis" class="col-md-4 col-form-label text-md-left">{{ __('Penulis') }}</label>

                        <div class="col-md-12">
                            <input id="penulis" type="text-area" class="form-control @error('penulis') is-invalid @enderror" name="penulis"
                             value="{{ old('penulis') }}" placeholder="" required autocomplete="penulis">

                            @error('penulis')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="text">Isi</label>
                        <textarea name="text" id="text" cols="82" rows="10" placeholder="text"></textarea>
                    </div>

                    <div class="form-group row">
                        <b class="col-md-4 col-form-label text-md-left">File Gambar</b><br/>
                        <div class="col-md-12">
                            <input type="file" name="file" id="file">
                        </div>
                    </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-danger">{{ __('Save') }} </button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </form>
        </div>
    </div>
</div>
</div>
{{-- akhir modal tambah --}}
 
@endsection
