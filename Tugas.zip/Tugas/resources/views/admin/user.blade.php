@extends('layouts.hedadmin')

@section('content')
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
     <h1 class="h3 mb-0 text-gray-800">Articel</h1>
     <a href="#" data-toggle="modal" data-target="#tambah" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Tambah Articel</a>
   </div>

 <!-- Content Row -->
 <div class="row">
   <div class="col-xl-12 col-md-6 mb-12">
     <div class="card border-left shadow h-100 py-12">
       <div class="card-body">
         <!-- DataTales Example -->
           <h6 class="m-0 font-weight-bold text-primary">DataTables Aticel</h6>
         </div>
         <div class="card-body">
           <div class="table-responsive">
             <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
               <thead>
                 <tr>
                   <th>Nama</th>
                   <th>Email</th>
                   <th>Tanggal aktif</th>
                   <th>Aksi</th>
                 </tr>
               </thead>
               @foreach($user as $ar)
               <tbody>
                 <tr>
                   <td>{{$ar->name}}</td>
                   <td>{{$ar->email}}</td>
                   <td>{{$ar->created_at}}</td>
                   <td>
                     <a href="" data-toggle="modal" data-target="#edit{{$ar->id}}" class="btn btn-warning btn-circle">
                       <i class="fas fa-edit"></i>
                     </a>
                    <a title="Hapus Data" href="user/hapus{{$ar->id}}"
                       onClick="return confirm('Yakin Ingin menghapus data?')"
                       class="btn btn-danger btn-circle"><span
                       class="fas fa-trash"></span></a>
                     </a>
                   </td>
                 </tr>
               </tbody>
               <!-- Modal edit-->
             <div class="modal fade" id="edit{{$ar->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
               aria-hidden="true">
               <div class="modal-dialog modal-dialog-centered" role="document">
                   <div class="modal-content">
                       <div class="modal-header">
                           <h5 class="modal-title" id="exampleModalCenterTitle">Edit Articel</h5>
                           <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                               <span aria-hidden="true">&times;</span>
                           </button>
                       </div>
                       <div class="modal-body">
                           <div class="card-body">
                               <form method="POST" action="/user/edit" enctype="multipart/form-data" >
                                   @csrf
                                   <input type="hidden" id="id" name="id" value="{{$ar->id}}">
                                   <div class="form-group row">
                                       <label for="name" class="col-md-4 col-form-label text-md-left">{{ __('name') }}</label>
               
                                       <div class="col-md-12">
                                           <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name"
                                            value="{{$ar->name}}" required autocomplete="name" autofocus>
               
                                           @error('name')
                                               <span class="invalid-feedback" role="alert">
                                                   <strong>{{ $message }}</strong>
                                               </span>
                                           @enderror
                                       </div>
                                   </div>
               
                                   <div class="form-group row">
                                       <label for="email" class="col-md-4 col-form-label text-md-left">{{ __('email') }}</label>
               
                                       <div class="col-md-12">
                                           <input id="penulis" type="text-area" class="form-control @error('email') is-invalid @enderror" name="email"
                                             value="{{$ar->email}}" placeholder="" required autocomplete="email">
               
                                           @error('email')
                                               <span class="invalid-feedback" role="alert">
                                                   <strong>{{ $message }}</strong>
                                               </span>
                                           @enderror
                                       </div>
                                   </div>
                           </div>
                       </div>
                       <div class="modal-footer">
                           <button type="submit" class="btn btn-danger">{{ __('Save') }} </button>
                           <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                           </form>
                       </div>
                   </div>
               </div>
               </div>
               {{-- akhir modal edit --}}
               @endforeach
             </table>
           </div>
         </div>
       </div>
   </div>
</div>

<!-- Modal Tambah-->
<div class="modal fade" id="tambah" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
aria-hidden="true">
<div class="modal-dialog modal-dialog-centered" role="document">
 <div class="modal-content">
     <div class="modal-header">
         <h5 class="modal-title" id="exampleModalCenterTitle">Tambah User</h5>
         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
             <span aria-hidden="true">&times;</span>
         </button>
     </div>
     <div class="modal-body">
         <div class="card-body">
            <form method="POST" action="{{ route('register') }}">
                @csrf

                <div class="form-group row">
                    <label for="name" class="col-md-4 col-form-label text-md-left">{{ __('Name') }}</label>

                    <div class="col-md-8">
                        <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>

                        @error('name')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                </div>

                <div class="form-group row">
                    <label for="email" class="col-md-4 col-form-label text-md-left">{{ __('E-Mail Address') }}</label>

                    <div class="col-md-8">
                        <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email">

                        @error('email')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                </div>

                <div class="form-group row">
                    <label for="password" class="col-md-4 col-form-label text-md-left">{{ __('Password') }}</label>

                    <div class="col-md-8">
                        <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                        @error('password')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                </div>

                <div class="form-group row">
                    <label for="password-confirm" class="col-md-4 col-form-label text-md-left">{{ __('Confirm Password') }}</label>

                    <div class="col-md-8">
                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                    </div>
                </div>
         </div>
     </div>
     <div class="modal-footer">
         <button type="submit" class="btn btn-danger">{{ __('Save') }} </button>
         <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
         </form>
     </div>
 </div>
</div>
</div>
{{-- akhir modal tambah --}}
@endsection
